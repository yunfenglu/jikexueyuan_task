/**
 * Created by yunfeng on 2015/10/21.
 */
//喜欢的颜色为红色
function navBgColorRed(id){
    document.getElementById("navbarwrapper").style.borderTopColor ="#ff0000";
    document.getElementById("on").style.background = "#ff0000";
    var target = document.getElementById(id);
    var str = target.value;
    localStorage.setItem("message","#ff0000");
}

//喜欢的颜色为绿色
function navBgColorBlue(id){
    document.getElementById("navbarwrapper").style.borderTopColor ="#0000ff";
    document.getElementById("on").style.background = "#0000ff";
    var target = document.getElementById(id);
    var str = target.value;
    localStorage.setItem("message","#0000ff");
}
//喜欢的颜色为紫色
function navBgColorYellow(id){
    document.getElementById("navbarwrapper").style.borderTopColor ="#9c87fa";
    document.getElementById("on").style.background = "#9c87fa";
    var target = document.getElementById(id);
    var str = target.value;
    localStorage.setItem("message","#9c87fa");
}

window.onload = function(){
        var theme = localStorage.getItem("message");
        document.getElementById("navbarwrapper").style.borderTopColor = theme;
        document.getElementById("on").style.background = theme;
}