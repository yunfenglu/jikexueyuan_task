/**
 * Created by yunfeng on 2015/10/28.
 */
$(document).ready(function(){
   $(window).on("load",function(){
       var dataImg = {"data":[{"src":"11.jpg"},{"src":"12.jpg"},{"src":"16.jpg"},{"src":"14.jpg"},{"src":"15.jpg"},
                                {"src":"18.jpg"}, {"src":"19.jpg"},{"src":"20.jpg"},{"src":"21.jpg"},{"src":"22.jpg"},
                                {"src":"23.jpg"}]};
       imgPosition();
       window.onscroll = function(){
            if(imagesLoad()){
                $.each(dataImg.data,function(index,value){
                    var box = $("<div>").addClass("box").appendTo($("#container"));
                    var content =  $("<div>").addClass("content").appendTo(box);
                    $("<img>").attr("src","./images/" + $(value).attr("src")).appendTo(content);
                });
                imgPosition();
            }
       };
   }) ;
});

function imagesLoad(){
    var box = $(".box");
    var lastboxHeight = box.last().get(0).offsetTop + Math.floor(box.last().height()/2);
    var documentHeight = $(document).width();
    var mouseScrolling = $(window).scrollTop();
    return (lastboxHeight < mouseScrolling + documentHeight) ? true : false;
}

function imgPosition(){
    var box = $(".box");
    var boxWidth = box.eq(0).width();
    var num = Math.floor($(window).width()/boxWidth);
    var boxArray = [];
    box.each(function(index,value){
        var boxHeight = box.eq(index).height();
        if (index<num){
            boxArray[index] = boxHeight;
        }else{
            var minboxHeight = Math.min.apply(null,boxArray);
            var minboxPosition = $.inArray(minboxHeight,boxArray);
            $(value).css({
               "position":"absolute",
                "top": minboxHeight,
                "left":box.eq(minboxPosition).position().left
            });
            boxArray[minboxPosition] += box.eq(index).height();
        }
    });
}