/**
 * Created by yunfeng on 2015/11/5.
 */
$(document).ready(function(){
    //广告图
    $(".vip-guanggao>i").click(function(){
       $(this).parent(".vip-guanggao").fadeOut();
    });
    $(".shuangshiyi-guanggao>i").click(function(){
        $(this).parent(".shuangshiyi-guanggao").fadeOut();
    });

    //搜索框部分
    $(".headsearch").click(function(e){
       $(this).children(".hot-words").css("display","none");
       $(".search-btn1").addClass("search-btnxuanzhong");
       $(".search-btn1").removeClass("search-btn");
        e.stopPropagation()
    });
    $(document).click(function(){
        $(".hot-words").css("display","block");
        $(".search-btn1").removeClass("search-btnxuanzhong");
        $(".search-btn1").addClass("search-btn");
    });
    //会员登陆显示、隐藏会员内容
    $(".userMenu").hover(function(){
        $(this).children(".userMenu-menu").show();
    },function(){
        $(this).children(".userMenu-menu").hide();
    });

    //内容部分导航菜单 隐藏/显示 内容
    $(".lesson-classfiy-nav>ul>li>div").hover(function(){
        $(this).children(".lesson-list-show").show();
        $(".hide").show();
        $(".line").css("display","none");
        $(".lesson-classfiy-nav>ul").css("height","408px");
    },function(){
        $(this).children(".lesson-list-show").hide();
        $(".line").css("display","block");
        $(".hide").hide();
        $(".lesson-classfiy-nav>ul").css("height","305px");
    });

    //右边 gotop  div隐藏的在线客服样式
    $(".zaixiankefu").hover(function(){
       $(this).children("div"). fadeToggle();
    });

    //第二部分内容导航的 选中设置
    //第三部分内容鼠标经过切换内容
    $(".hot-lesson-li1").hover(function(){
        $(this).siblings("li").removeClass("on");
        $(this).addClass("on");
        $(".one-classfiy-lesson").show();
        $(".one-classfiy-lesson2").hide();
        $(".one-classfiy-lesson3").hide();
        $(".one-classfiy-lesson4").hide();
        $(".one-classfiy-lesson5").hide();
        $(".one-classfiy-lesson6").hide();
    });

    $(".hot-lesson-li2").hover(function(){
        $(this).siblings("li").removeClass("on");
        $(this).addClass("on");
        $(".one-classfiy-lesson2").show();
        $(".one-classfiy-lesson").hide();
        $(".one-classfiy-lesson3").hide();
        $(".one-classfiy-lesson4").hide();
        $(".one-classfiy-lesson5").hide();
        $(".one-classfiy-lesson6").hide();
    });
    $(".hot-lesson-li3").hover(function(){
        $(this).siblings("li").removeClass("on");
        $(this).addClass("on");
        $(".one-classfiy-lesson2").hide();
        $(".one-classfiy-lesson").hide();
        $(".one-classfiy-lesson3").show();
        $(".one-classfiy-lesson4").hide();
        $(".one-classfiy-lesson5").hide();
        $(".one-classfiy-lesson6").hide();
    });
    $(".hot-lesson-li4").hover(function(){
        $(this).siblings("li").removeClass("on");
        $(this).addClass("on");
        $(".one-classfiy-lesson2").hide();
        $(".one-classfiy-lesson").hide();
        $(".one-classfiy-lesson3").hide();
        $(".one-classfiy-lesson4").show();
        $(".one-classfiy-lesson5").hide();
        $(".one-classfiy-lesson6").hide();
    });
    $(".hot-lesson-li5").hover(function(){
        $(this).siblings("li").removeClass("on");
        $(this).addClass("on");
        $(".one-classfiy-lesson2").hide();
        $(".one-classfiy-lesson").hide();
        $(".one-classfiy-lesson3").hide();
        $(".one-classfiy-lesson4").hide();
        $(".one-classfiy-lesson5").show();
        $(".one-classfiy-lesson6").hide();
    });
    $(".hot-lesson-li6").hover(function(){
        $(this).siblings("li").removeClass("on");
        $(this).addClass("on");
        $(".one-classfiy-lesson2").hide();
        $(".one-classfiy-lesson").hide();
        $(".one-classfiy-lesson3").hide();
        $(".one-classfiy-lesson4").hide();
        $(".one-classfiy-lesson5").hide();
        $(".one-classfiy-lesson6").show();
    });

    //第三部分内容img设置
    $(".lessonimg-wrapper").hover(function(){
        $(this).find(".lessonplay").css("opacity","1");
        $(this).find(".lesson-infor").css("height","175px");
        $(this).find("p").slideDown(500);
        $(this).find(".zhongji").show();
        $(this).find(".learn-number").show();
        $(this).find(".lesson-shoucang").show();
    },function(){
        $(this).find(".zhongji").hide(500);
        $(this).find(".learn-number").hide(500);
        $(this).find(".lessonplay").css("opacity","0");
        $(this).find(".lesson-infor").css("height","88px");
        $(this).find("p").slideUp(500);
        $(this).find(".lesson-shoucang").hide();
    });

    //第四部分职业路径图 鼠标经过边框更改颜色的样式
    $(".learn-card1").hover(function(){
        $(this).css("border-bottom"," 1px solid rgb(53,181,88)");
       $(this).next(".learn-card2").css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-bottom"," 1px solid rgb(228, 228, 228)");
        $(this).next(".learn-card2").css("border-left"," 1px solid rgb(228, 228, 228)");
    });

    $(".learn-card2").hover(function(){
        $(this).css("border-bottom"," 1px solid rgb(53,181,88)");
        $(this).css("border-left"," 1px solid rgb(53,181,88)");
        $(this).next(".learn-card3").css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-bottom"," 1px solid rgb(228, 228, 228)");
        $(this).css("border-left"," 1px solid rgb(228, 228, 228");
        $(this).next(".learn-card3").css("border-left"," 1px solid rgb(228, 228, 228)");
    });

    $(".learn-card3").hover(function(){
        $(this).css("border-bottom"," 1px solid rgb(53,181,88)");
        $(this).css("border-left"," 1px solid rgb(53,181,88)");
        $(this).next(".learn-card4").css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-bottom"," 1px solid rgb(228, 228, 228)");
        $(this).css("border-left"," 1px solid rgb(228, 228, 228");
        $(this).next(".learn-card4").css("border-left"," 1px solid rgb(228, 228, 228)");
    });

    $(".learn-card4").hover(function(){
        $(this).css("border-bottom"," 1px solid rgb(53,181,88)");
        $(this).css("border-left"," 1px solid rgb(53,181,88)");
        $(this).next(".learn-card5").css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-bottom"," 1px solid rgb(228, 228, 228)");
        $(this).css("border-left"," 1px solid rgb(228, 228, 228");
        $(this).next(".learn-card5").css("border-left"," 1px solid rgb(228, 228, 228)");
    });

    $(".learn-card5").hover(function(){
        $(this).css("border-bottom"," 1px solid rgb(53,181,88)");
        $(this).css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-bottom"," 1px solid rgb(228, 228, 228)");
        $(this).css("border-left"," 1px solid rgb(228, 228, 228");
    });

    $(".learn-card6").hover(function(){
        $(".learn-card1").css("border-bottom"," 1px solid rgb(53,181,88)");
        $(this).next(".learn-card7").css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).next(".learn-card7").css("border-left"," 1px solid rgb(228, 228, 228)");
        $(".learn-card1").css("border-bottom"," 1px solid rgb(228, 228, 228)");
    });

    $(".learn-card7").hover(function(){
        $(this).css("border-left"," 1px solid rgb(53,181,88)");
        $(".learn-card2").css("border-bottom"," 1px solid rgb(53,181,88)");
        $(this).next(".learn-card8").css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-left"," 1px solid rgb(228, 228, 228)");
        $(this).next(".learn-card8").css("border-left"," 1px solid rgb(228, 228, 228)");
        $(".learn-card2").css("border-bottom"," 1px solid rgb(228, 228, 228)");
    });

    $(".learn-card8").hover(function(){
        $(this).css("border-left"," 1px solid rgb(53,181,88)");
        $(".learn-card3").css("border-bottom"," 1px solid rgb(53,181,88)");
        $(this).next(".learn-card9").css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-left"," 1px solid rgb(228, 228, 228)");
        $(this).next(".learn-card9").css("border-left"," 1px solid rgb(228, 228, 228)");
        $(".learn-card3").css("border-bottom"," 1px solid rgb(228, 228, 228)");
    });

    $(".learn-card9").hover(function(){
        $(this).css("border-left"," 1px solid rgb(53,181,88)");
        $(".learn-card4").css("border-bottom"," 1px solid rgb(53,181,88)");
        $(this).next(".learn-card10").css("border-left"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-left"," 1px solid rgb(228, 228, 228)");
        $(this).next(".learn-card10").css("border-left"," 1px solid rgb(228, 228, 228)");
        $(".learn-card4").css("border-bottom"," 1px solid rgb(228, 228, 228)");
    });

    $(".learn-card10").hover(function(){
        $(this).css("border-left"," 1px solid rgb(53,181,88)");
        $(".learn-card5").css("border-bottom"," 1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border-left"," 1px solid rgb(228, 228, 228)");
        $(".learn-card5").css("border-bottom"," 1px solid rgb(228, 228, 228)");
    });

    $(".way").mouseover(function(){
        $(this).siblings(".way-infor").animate({
            marginLeft:'0',
            opacity:'1'
        });
    });
    $(".way").mouseout(function(){
       $(this).siblings(".way-infor").animate({
           marginLeft:'-5px',
           opacity:'0'
       }) ;
    });
    //wiki部分边框滑过样式
    $(".one-wiki1").hover(function(){
        $(this).css("border","1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border","1px solid rgb(228, 228, 228)");
    });

    $(".one-wiki2").hover(function(){
        $(this).css("border","1px solid rgb(53,181,88)");
        $(this).css("border-left","0");
        $(".one-wiki1").css("border-right","1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border","1px solid rgb(228, 228, 228)");
        $(this).css("border-left","0");
        $(".one-wiki1").css("border-right","1px solid rgb(228, 228, 228)");
    });

    $(".one-wiki3").hover(function(){
        $(this).css("border","1px solid rgb(53,181,88)");
        $(this).css("border-left","0");
        $(".one-wiki2").css("border-right","1px solid rgb(53,181,88)");
    },function(){
        $(this).css("border","1px solid rgb(228, 228, 228)");
        $(this).css("border-left","0");
        $(".one-wiki2").css("border-right","1px solid rgb(228, 228, 228)");
    });

    //中间大的轮播图 左右n却换按钮
    $(".index-banner").hover(function(){
        $("#banner-right"). fadeToggle();
        $("#banner-left"). fadeToggle();
    });

    //合作伙伴 左右切换按钮
    $(".strategy-huoban").hover(function(){
        $("#banner-right3"). fadeToggle();
        $("#banner-left3"). fadeToggle();
    });
    //合作院校  左右切换按钮
    $(".swiper-car-box ").hover(function(){
        $("#banner-right2"). fadeToggle();
        $("#banner-left2"). fadeToggle();
    });

    //媒体报道  左右切换按钮
    $(".strategy-meiti").hover(function(){
        $("#banner-right4"). fadeToggle();
        $("#banner-left4"). fadeToggle();
    });

});
