/**
 * Created by yunfeng on 2015/10/31.
 */
$(document).ready(function(){
    //会员登陆鼠标经过内容弹出
    $("#username").mousemove(function(){
        $("#username-menu").slideDown();
    });
    $("#username-menu").mouseleave(function(){
        $("#username-menu").slideUp();
    });

//设置部分鼠标经过内容弹出
    $("#seting").mousemove(function(){
        $("#set-tu-menu").slideDown();
    });
    $("#set-tu-menu").mouseleave(function(){
        $("#set-tu-menu").slideUp();
    });

    //更多产品部分样式
    $("#product").mousemove(function(){
        $("#products").css({
            'display':'block',
           'z-index':'9999'
        });
        $("#product").css("opacity","0");
    });
    $("#products").mouseleave(function(){
        $("#products").slideUp();
        $("#product").css("opacity","1");
    });

       //内容菜单切换
    $("#title-content-navmine").click(function(){
        $(".title-content-daohangicondown em").toggleClass("emdown");
        $(".my-blank-daohang").slideToggle();
    });
    $("#title-content-vediomine").click(function(){
        $(".title-content-vedioicondown em").toggleClass("emdown");
        $(".my-blank-shipin").slideToggle();
    });
    $("#title-content-xingzuomine").click(function(){
        $(".title-content-xingzuoicondown em").toggleClass("emdown");
        $(".wodexingzuo-wrapper").slideToggle();
    });

    //主体内同导航菜单切换
    //关注
    $(".content-navmenu-guanzhu").click(function(){
        $(this).addClass("bg-on");
        $(".content-navmenu-item1").removeClass("bg-on");
        $(".content-navmenu-item2").removeClass("bg-on");
        $(".content-navmenu-item3").removeClass("bg-on");
        $(".content-navmenu-item4").removeClass("bg-on");
        $(".content-contents").show();
        $(".nav-contents").hide();
        $(".video-contents").hide();
        $(".play-contents").hide();
        $(".shopping-contents").hide();
    });
    //导航
    $(".content-navmenu-item1").click(function(){
        $(this).addClass("bg-on");
        $(".content-navmenu-guanzhu").removeClass("bg-on");
        $(".content-navmenu-item2").removeClass("bg-on");
        $(".content-navmenu-item3").removeClass("bg-on");
        $(".content-navmenu-item4").removeClass("bg-on");
        $(".content-contents").hide();
        $(".nav-contents").show();
        $(".video-contents").hide();
        $(".play-contents").hide();
        $(".shopping-contents").hide();
    });
    //视频
    $(".content-navmenu-item2").click(function(){
        $(this).addClass("bg-on");
        $(".content-navmenu-item1").removeClass("bg-on");
        $(".content-navmenu-guanzhu").removeClass("bg-on");
        $(".content-navmenu-item3").removeClass("bg-on");
        $(".content-navmenu-item4").removeClass("bg-on");
        $(".content-contents").hide();
        $(".nav-contents").hide();
        $(".video-contents").show();
        $(".play-contents").hide();
        $(".shopping-contents").hide();
    });
    //体育
    $(".content-navmenu-item3").click(function(){
        $(this).addClass("bg-on");
        $(".content-navmenu-item1").removeClass("bg-on");
        $(".content-navmenu-item2").removeClass("bg-on");
        $(".content-navmenu-guanzhu").removeClass("bg-on");
        $(".content-navmenu-item4").removeClass("bg-on");
        $(".content-contents").hide();
        $(".nav-contents").hide();
        $(".video-contents").hide();
        $(".play-contents").show();
        $(".shopping-contents").hide();
    });
    //购物
    $(".content-navmenu-item4").click(function(){
        $(this).addClass("bg-on");
        $(".content-navmenu-item1").removeClass("bg-on");
        $(".content-navmenu-item2").removeClass("bg-on");
        $(".content-navmenu-item3").removeClass("bg-on");
        $(".content-navmenu-guanzhu").removeClass("bg-on");
        $(".content-contents").hide();
        $(".nav-contents").hide();
        $(".video-contents").hide();
        $(".play-contents").hide();
        $(".shopping-contents").show();
    });

    //导航内容的 元素显示返利信息
    $(".nav-block").mousemove(function(){
        $(this).siblings(".rebate").fadeIn();
    });

    $(".nav-item").mouseleave(function(){
        $(this).children(".rebate").fadeOut();
    });
    //视频内容的 显示收藏 和删除收藏信息
    $(".item-wrapper").hover(function(){
       $(this).find(".tag-sort").hide();
       $(this).find(".unsub").show();
       $(this).find(".dustbin").show();
    },function(){
        $(this).find(".tag-sort").show();
        $(this).find(".unsub").hide();
        $(this).find(".dustbin").hide();
    });

    //购物页面 鼠标滑过弹出 购买记录信息
    $(".shopping-card-item").hover(function(){
       $(this).find(".mask").show();
    },function(){
        $(this).find(".mask").hide();
    });
});
