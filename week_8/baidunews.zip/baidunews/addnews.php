<?php
	if(!isset($_POST['newstitle'])){
		die("请填写新闻标题！！！");
	}
	if(!isset($_POST['newsimg'])){
		die("请添加新闻图片！！！");
	}
	if(!isset($_POST['newscontent'])){
		die("请填写新闻内容！！！");
	}

	$newstitle = $_POST['newstitle'];
	if(empty($newstitle)){
		die('请填写新闻标题！！！');
	}
	$newsimg = $_POST['newsimg'];
	if(empty($newsimg)){
		die('请添加新闻图片！！！');
	}
	$newscontent = $_POST['newscontent'];
	if(empty($newscontent)){
		die('请填写新闻内容！！！');
	}

	require_once 'functions.php';
	$conn = connectDb();
	mysql_query("SET NAMES 'utf8'");
	mysql_query("INSERT INTO `news`(`newstitle`, `newsimg`, `newscontent`) VALUES ('$newstitle','$newsimg','$newscontent')");
	if(mysql_errno()){
		echo mysql_error();
	}else{
		header("location:allnews.php");
	}

?>