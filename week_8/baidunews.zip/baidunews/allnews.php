<?php
	require_once 'functions.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>新闻列表</title>
</head>
<body>
	<a href="addnews.html">添加新闻</a>
	<table border='1'>
		<tr>
			<th>新闻ID</th>
			<th>新闻标题</th>
			<th>新闻图片</th>
			<th>新闻内容</th>
			<th>添加时间</th>
			<th>修改新闻</th>
			<th>删除新闻</th>
		</tr>
	<?php
		$conn = connectDb();
		mysql_query("SET NAMES 'utf8'");
		mysql_query("SET CHARACTER SET utf8");
		mysql_query("SET CHARACTER_SER_RESULT=utf8");
		$result = mysql_query("SELECT * FROM news");
		$dataConnt = mysql_num_rows($result);
	
		for ($i=0; $i < $dataConnt; $i++) { 
			$result_arr = mysql_fetch_assoc($result);
			$newsid = $result_arr['newsid'];
			$newstitle = $result_arr['newstitle'];
			$newsimg = $result_arr['newsimg'];
			$newscontent = $result_arr['newscontent'];
			$addtime = $result_arr['addtime'];
		echo "<tr><td>$newsid</td><td>$newstitle</td><td>$newsimg</td><td>$newscontent</td><td>$addtime</td><td><a href='editnews.php?newsid=$newsid'>修改新闻</a></td><td><a href='delnews.php?newsid=$newsid'>删除新闻</a></td></tr>";	
		}
	?>
	</table>
</body>
</html>