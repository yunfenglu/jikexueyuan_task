<?php

	if(empty($_GET['newsid'])){
		die('新闻ID为空');
	}

	require_once 'functions.php';
	connectDb();
	$newsid = intval($_GET['newsid']);
	mysql_query("DELETE FROM `news` WHERE newsid = $newsid");
	if(mysql_errno()){
		die("无法删除新闻：$newsid");
	}else{
		header("location:allnews.php");
	}
?>