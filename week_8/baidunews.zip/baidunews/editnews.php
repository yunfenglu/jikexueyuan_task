<!DOCTYPE html>
<html>
<head>
	<meta chatset="utf-8"/>
	<title>修改新闻</title>
</head>
<body>

<?php
	require_once 'functions.php';
	if(!empty($_GET['newsid'])){
		connectDb();
		mysql_query("SET NAMES 'utf8'");
		mysql_query("SET CHARACTER SET utf8");
		mysql_query("SET CHARACTER_SER_RESULT=utf8");
		$newsid = intval($_GET['newsid']);
		$result = mysql_query("SELECT * FROM news WHERE newsid = $newsid");		
		if(mysql_errno()){
			die("数据库连接错误！");
		}
		$arr = mysql_fetch_assoc($result);
	}else{
		die("没有相应的新闻ID");
	}
?>
<form action="editnews_server.php" method="post">
	<p>
        <label for="newsid">新闻标题</label>
        <input type="text" name="newsid"  value="<?php echo $arr['newsid']; ?>">
    </p>
	<p>
        <label for="newstitle">新闻标题</label>
        <input type="text" name="newstitle"  value="<?php echo $arr['newstitle']; ?>">
    </p>
    <p>
        <label for="newsimg">新闻图片</label>
        <input type="file" name="newsimg" value="<?php echo $arr['newsimg']; ?>">
    </p>
    <p>
        <label for="newscontent">新闻内容</label>
        <input type="text" name="newscontent" value="<?php echo $arr['newscontent']; ?>">
    </p>
     <p>
        <label for="addtime">修改时间</label>
        <input type="date" name="addtime" value="<?php echo $arr['addtime']; ?>">
    </p>
    <p>
        <input type="submit" value="确认修改">
    </p>
</form>
</html>
</body>