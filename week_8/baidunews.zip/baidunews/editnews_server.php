<?php
	require_once 'functions.php';

	if(empty($_POST['newsid'])){
		die('新闻ID为空');
	}
	if(empty($_POST['newstitle'])){
		die('新闻标题为空');
	}
	if(empty($_POST['newsimg'])){
		die('新闻图片为空');
	}
	if(empty($_POST['newscontent'])){
		die('新闻内容为空');
	}
	if(empty($_POST['addtime'])){
		die('新闻修改时间为空');
	}

	$newsid = intval($_POST['newsid']);
	$newstitle = $_POST['newstitle'];
	$newsimg = $_POST['newsimg'];
	$newscontent = $_POST['newscontent'];
	$addtime = $_POST['addtime'];
	
	connectDb();
	mysql_query("SET NAMES 'utf8'");
	mysql_query("SET CHARACTER SET utf8");
	mysql_query("SET CHARACTER_SER_RESULT=utf8");
	mysql_query("UPDATE news SET `newstitle`='$newstitle',`newsimg`='$newsimg',`newscontent`='$newscontent',`addtime`='$addtime' WHERE newsid = $newsid");
	if(mysql_errno()){
		echo mysql_error();
	}else{
		header("location:allnews.php");
	}
?>