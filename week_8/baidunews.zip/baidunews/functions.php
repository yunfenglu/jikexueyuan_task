<?php
	require_once 'config.php';
	mysql_query("SET NAMES 'utf8'");
	mysql_query("SET CHARACTER SET utf8");
	mysql_query("SET CHARACTER_SER_RESULT=utf8");
	function connectDb(){
		$conn = mysql_connect(MYSQL_HOST,MYSQL_USER,MYSQL_PW);
		if(!$conn){
			die("无法链接数据库！");
		}
		mysql_select_db('baidunews');
		return $conn;
	}
?>