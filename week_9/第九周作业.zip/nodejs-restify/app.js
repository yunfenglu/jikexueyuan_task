var restify = require('restify');
var orm = require("orm");
function respond(req, res, next) {
	orm.connect("mysql://root:@localhost/baidunews", function (err, db) {
  	if (err) throw err;
 
	var News = db.define("news", {
		newsid: {
			type:'serial',
			key:true
		},
		newstitle: String,
		newsimg: String, 
		newscontent: String,
		addtime: Date 
	});
	News.find({},function(err,news){
		//console.log(news);
		//res.send('hello ' + req.params.newsid);
		res.charSet('utf-8');
		res.json(news);
	});
});

}

var server = restify.createServer();
server.get('/hello/:newsid', respond);
server.post('/hello/:name', respond);


server.listen(3900, function() {
  console.log('%s listening at %s', server.name, server.url);
});