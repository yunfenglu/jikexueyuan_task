-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2015-12-03 04:53:04
-- 服务器版本： 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baidunews`
--

-- --------------------------------------------------------

--
-- 表的结构 `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `newsid` bigint(20) NOT NULL,
  `newstitle` varchar(255) NOT NULL,
  `newsimg` text NOT NULL,
  `newscontent` text NOT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `news`
--

INSERT INTO `news` (`newsid`, `newstitle`, `newsimg`, `newscontent`, `addtime`) VALUES
(1, '我是修改的内容22', 'news-1.jpg', '我是修改的内容222', '2015-12-02 16:00:00'),
(2, '李克强总理做高铁体验', 'zongli.jpg', '李克强总理和多国总理一起体验中国高铁！', '2015-12-01 16:00:00'),
(3, '收拾收拾收拾收拾收拾收拾', 'news-5.jpg', '少时诵诗书', '2015-12-01 16:00:00'),
(8, '我是修噶的', 'bg-footer_7e7ec6c.png', '我是修改的', '2015-11-30 16:00:00'),
(10, '是是是  是 ', '试试是是 是是 ', '试是是是是是是 ', '0000-00-00 00:00:00'),
(11, '试试是是  ', '试试是是 ', '试试是是是', '2015-12-01 16:00:00'),
(13, '是 是试试是', '是是 试试', '是是试试是是', '0000-00-00 00:00:00'),
(14, '是 是试试 是是撒啊啊啊', '啊啊啊啊啊', '啊  啊啊啊啊啊啊啊啊啊啊啊', '0000-00-00 00:00:00'),
(15, 'www问问', 'www问问', '问问呜呜呜呜呜呜', '0000-00-00 00:00:00'),
(16, '收拾收拾', '是是是', '啊啊我才v丰富发发发 ', '0000-00-00 00:00:00'),
(17, '我是修改的内容2', 'bg-footer_7e7ec6c.png', '1我是修改的内容额', '2015-12-01 16:00:00'),
(18, '12333', '12333233', '12222222', '2015-12-02 08:56:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`newsid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `newsid` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
