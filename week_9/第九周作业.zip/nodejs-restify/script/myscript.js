/**
 * Created by yunfeng on 2015/11/24.
 */
$(document).ready(function(){
   $(".more").on("click",function(){
       $(this).hide();
       $(".content > table > tbody > tr").show();
       $("#index_view_navigator >.divider").show();
       $("#index_view_navigator >.footer").show();
   });
   $(".less").on("click",function(){
       $(".more").show();
       $("#index_view_navigator .content table tbody tr:nth-child(5)").hide();
       $("#index_view_navigator .content table tbody tr:nth-child(4)").hide();
       $("#index_view_navigator .content table tbody tr:nth-child(3)").hide();
       $("#index_view_navigator >.divider").hide();
       $("#index_view_navigator >.footer").hide();
       });

    //热点新闻

});
